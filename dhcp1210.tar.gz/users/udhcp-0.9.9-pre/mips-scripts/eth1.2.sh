#!/bin/sh

exec /usr/share/udhcpc/eth1.2.$1
