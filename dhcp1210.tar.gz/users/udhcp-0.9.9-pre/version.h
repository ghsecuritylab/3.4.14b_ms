#ifndef _UDHCP_VERSION_H
#define _UDHCP_VERSION_H

#define VERSION "0.9.9-pre"

#endif
