
/*
Copyright (c) 2019, All rights reserved.

File         : slaveUpgrade.h
Status       : Current
Description  : 

Author       : lhw
Contact      : xxhanwen@163.com

Revision     : 2019-10 
Description  : Primary released

## Please log your description here for your modication ##

Revision     : 
Modifier     : 
Description  : 

*/


#ifndef __SLAVE_UPGRADE_H__
#define __SLAVE_UPGRADE_H__

extern int SendFileToSlave(char *file_data, int file_len, char *slave_ip, int slave_port);

#endif /* #ifndef __SLAVE_UPGRADE_H__ */

