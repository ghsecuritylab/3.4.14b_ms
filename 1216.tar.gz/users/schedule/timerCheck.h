
/*
Copyright (c) 2019, All rights reserved.

File         : timerCheck.h
Status       : Current
Description  : 

Author       : lhw
Contact      : xxhanwen@163.com

Revision     : 2019-09 
Description  : Primary released

## Please log your description here for your modication ##

Revision     : 
Modifier     : 
Description  : 

*/


#ifndef __TIMER_CHECK_H__
#define __TIMER_CHECK_H__

extern void InitTimerCheck();
extern int timerCheck();
extern int doMAPCheck();


#endif /* #ifndef __TIMER_CHECK_H__ */

