#ifndef __WEBTOPOLOGY_H__
#define __WEBTOPOLOGY_H__

#define MIB_ELAN_MAC_ADDR		23

#endif

