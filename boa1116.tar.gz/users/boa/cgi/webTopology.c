#include <stdio.h>
#include <unistd.h>
#include <fcntl.h>
#include <string.h>
#include <stdlib.h>

#define WEB_TOPOLOGY_TXT "/tmp/web_topology.txt"

#define WEB_TOPOLOGY_SIZE 10240

char* webMeshTopology ()
{
    int  fd = 0;
    int  len = 0;
    char buf[WEB_TOPOLOGY_SIZE];

#if 1
    fd = open(WEB_TOPOLOGY_TXT, O_RDONLY);
	if (fd < 1)
		return "{}";
    len = read(fd, buf, WEB_TOPOLOGY_SIZE);

    close(fd);

	if (len > 1)
		return buf;
	else
		return "{}";
#else
	
		return "{}";
#endif
} /* ----- End of main() ----- */
